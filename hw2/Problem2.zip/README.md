HOW TO RUN:-

* Run the file Bigram_Probability.py
* On the command line interface type the file name with the python extension, 
  followed by one argument which contains the input string (must be in "").
  Eg: python Part_of_Speech_Tagging.py "Input Test String"
* Corpus File must be in the same folder as the Bigram_Probability.py file.
* Corpus File Name must be : "HW2_F17_NLP6320-NLPCorpusTreebank2Parts-CorpusA-Unix.txt"

OUTPUT:-

* The command line will display the probabilities for the 3 models :
	* Bigram model without smoothing
	* Bigram model with Add one smoothing
	* Bigram model with Good Turing discounting
* Following files will be generated upon running the program.
	* "Bigram_Probability.txt" - contains the Bigram, Counts and Probabilities of the bigrams in the corpus for bigram model without smoothing
	* "Add_One_Smoothing.txt" - contains the Bigram, counts and probabilities of the bigrams in the corpus for bigram model with Add One Smoothing
	* "Good_Turing_Discounting.txt" - contains the Bigram, counts and probabilities of the bigrams in the corpus for bigram model with Good Turing Discounting
	* "Bigram_Probability-output.txt" - contains final probability of the sentence for bigram model without smoothing
	* "Add_One_Smoothing-output.txt" - contains final probability of the sentence for bigram model with Add one smoothing
	* "Good_Turing_Discounting-output.txt" - contains final probability of the sentence for bigram model with Good Turing Discounting
**Minimum Python version required: 3.5



	