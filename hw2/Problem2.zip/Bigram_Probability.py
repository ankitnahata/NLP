import csv
import json, pickle
import sys


def data_read(file_path):
    data = []
    file = open(file_path, "r")
    for word in file.read().split():
        data.append(word)
    file.close()
    return data


def bigram_generator(data):
    bigram_list = []
    bigram_count = {}
    unigram_count = {}
    nbyn = {}

    for i in range(len(data)):
        if i < len(data) - 1:
            bigram_list.append((data[i], data[i + 1]))
            if (data[i], data[i + 1]) in bigram_count:
                bigram_count[(data[i], data[i + 1])] += 1
            else:
                bigram_count[(data[i], data[i + 1])] = 1

        if data[i] in unigram_count:
            unigram_count[data[i]] += 1
        else:
            unigram_count[data[i]] = 1
    return bigram_list, unigram_count, bigram_count


# Bigram without smoothing
def bigram_probablity(list_of_bigram, unigram_counts, bigram_counts):
    list_of_probability = {}
    for b in list_of_bigram:
        w1 = b[0]
        w2 = b[1]
        list_of_probability[b] = (bigram_counts.get(b)) / (unigram_counts.get(w1))

    file = open('Bigram_Probability.txt', 'w')
    file.write('!!!!!!!Bigram Probabilities!!!!!!!\n')
    file.write('BIGRAM' + '\t\t' + 'COUNT' + '\t' + 'PROBABILITY-B' + '\n')

    for bigrams in list_of_bigram:
        file.write(
            str(bigrams) + ' :\t\t ' + str(bigram_counts[bigrams]) + ' :\t ' + str(list_of_probability[bigrams]) + '\n')

    file.close()

    return list_of_probability


# Bigram with Add One Smoothing
def add_one_smoothing(list_of_bigram, unigram_counts, bigram_counts):
    list_of_probablity = {}
    c_star = {}

    for a in list_of_bigram:
        w1 = a[0]
        w2 = a[1]
        list_of_probablity[a] = (bigram_counts.get(a) + 1) / (unigram_counts.get(w1) + len(unigram_counts))
        c_star[a] = (bigram_counts[a] + 1) * unigram_counts[w1] / (unigram_counts[w1] + len(unigram_counts))

    file = open('Add_One_Smoothing.txt', 'w')
    file.write('!!!!!!!Add One Smoothing!!!!!!!\n')
    file.write('BIGRAM' + '\t\t' + 'COUNT' + '\t' + 'PROBABILITY-AOS' + '\n')

    for bigrams in list_of_bigram:
        file.write(
            str(bigrams) + ' : \t\t' + str(bigram_counts[bigrams]) + ' :\t ' + str(list_of_probablity[bigrams]) + '\n')

    file.close()

    return list_of_probablity, c_star


# Bigram with Good Turing Discounting
def good_turing_discounting(list_of_bigram, bigram_count, total_bigrams):
    list_of_probability = {}
    bucket = {}
    bucket_list = []
    c_star = {}
    p_star = {}
    list_of_counts = {}
    i = 1

    for g in bigram_count.items():
        key = g[0]
        v = g[1]

        if not v in bucket:
            bucket[v] = 1
        else:
            bucket[v] += 1

    # Sorted Bucket
    bucket_list = sorted(bucket.items(), key=lambda t: t[0])
    zero_occurence_probability = bucket_list[0][1] / total_bigrams
    last_item = bucket_list[len(bucket_list) - 1][0]

    for x in range(1, last_item):
        if x not in bucket:
            bucket[x] = 0

    bucket_list = sorted(bucket.items(), key=lambda t: t[0])

    for k, v in bucket_list:

        if i < len(bucket_list) - 1:
            if v == 0:
                c_star[k] = 0
                p_star[k] = 0

            else:
                c_star[k] = (i + 1) * bucket_list[i][1] / v
                p_star[k] = c_star[k] / total_bigrams

        else:
            c_star[k] = 0
            p_star[k] = 0

        i += 1

    for g in list_of_bigram:
        list_of_probability[g] = p_star.get(bigram_count[g])
        list_of_counts[g] = c_star.get(bigram_count[g])

    file = open('Good_Turing_Discounting.txt', 'w')
    file.write('!!!!!!!Good Turing Discounting!!!!!!!\n')
    file.write('BIGRAM' + '\t\t' + 'COUNT' + '\t' + 'PROBABILITY-GTD' + '\n')

    for bigrams in list_of_bigram:
        file.write(
            str(bigrams) + ' : \t\t' + str(bigram_count[bigrams]) + ' :\t ' + str(list_of_probability[bigrams]) + '\n')

    file.close()

    return list_of_probability, zero_occurence_probability, list_of_counts


if __name__ == '__main__':

    file_path = 'HW2_F17_NLP6320-NLPCorpusTreebank2Parts-CorpusA-Unix.txt'
    data = data_read(file_path)
    list_of_bigram, unigram_counts, bigram_counts = bigram_generator(data)
    bigram_probability = bigram_probablity(list_of_bigram, unigram_counts, bigram_counts)
    bigram_add_one, add_one_cstar = add_one_smoothing(list_of_bigram, unigram_counts, bigram_counts)
    bigram_good_turing, zero_occurence_probability, good_turing_cstar = good_turing_discounting(list_of_bigram,
                                                                                                bigram_counts,
                                                                                                len(list_of_bigram))

    sentence = sys.argv[1]
    # sentence = 'Richard W. Lock , retired vice '
    input_list = []
    output_b = open('Bigram_Probability-Output.txt', 'w')
    output_aos = open('Add_One_Smoothing-Output.txt', 'w')
    output_gtd = open('Good_Turing_Discounting-Output.txt', 'w')
    output_prob_b = 1
    output_prob_aos = 1
    output_prob_gtd = 1

    for i in range(len(sentence.split()) - 1):
        input_list.append((sentence.split()[i], sentence.split()[i + 1]))

    print(input_list)
    output_b.write('BIGRAM\t\t\t\t' + 'COUNT\t\t\t\t' + 'PROBABILITY\n\n')
    for i in range(len(input_list)):
        if input_list[i] in bigram_probability:
            output_b.write(str(input_list[i]) + '\t\t' + str(bigram_counts[input_list[i]]) + '\t\t' + str(
                bigram_probability[input_list[i]]) + '\n')
            output_prob_b *= bigram_probability[input_list[i]]
        else:
            output_b.write(str(input_list[i]) + '\t\t\t' + str(0) + '\t\t\t' + str(0) + '\n')
            output_prob_b *= 0

    output_b.write('\n' + 'PROBABILITY = ' + str(output_prob_b))
    print('Bigram: ', output_prob_b)

    output_aos.write('BIGRAM\t\t\t\t' + 'COUNT\t\t\t\t' + 'PROBABILITY\n\n')
    for i in range(len(input_list)):
        if input_list[i] in bigram_add_one:
            output_aos.write(str(input_list[i]) + '\t\t' + str(bigram_counts[input_list[i]] + 1) + '\t\t' + str(
                bigram_add_one[input_list[i]]) + '\n')
            output_prob_aos *= bigram_add_one[input_list[i]]
        else:
            if input_list[i][0] not in unigram_counts:
                unigram_counts[input_list[i][0]] = 1
            prob = (1) / (unigram_counts[input_list[i][0]] + len(unigram_counts))
            addOneCStar = 1 * unigram_counts[input_list[i][0]] / (
            unigram_counts[input_list[i][0]] + len(unigram_counts))
            output_prob_aos *= prob
            output_aos.write(str(input_list[i]) + '\t' + str(1) + '\t' + str(prob) + '\n')

    output_aos.write('\n' + 'PROBABILITY = ' + str(output_prob_aos))
    print('Add One Smoothing : ', output_prob_aos)

    output_gtd.write('BIGRAM\t\t\t\t' + 'COUNT\t\t\t\t' + 'PROBABILITY\n\n')
    for i in range(len(input_list)):
        if input_list[i] in bigram_good_turing:
            output_gtd.write(str(input_list[i]) + '\t\t' + str(good_turing_cstar[input_list[i]]) + '\t\t' + str(
                bigram_good_turing[input_list[i]]) + '\n')
            output_prob_gtd *= bigram_good_turing[input_list[i]]
        else:
            output_gtd.write(str(input_list[i]) + '\t\t\t' + str(0) + '\t\t\t' + str(zero_occurence_probability) + '\n')
            output_prob_gtd *= zero_occurence_probability

    output_gtd.write('\n' + 'PROBABILITY = ' + str(output_prob_gtd))
    print('Good Turing Discounting : ', output_prob_gtd)
