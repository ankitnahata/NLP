import sys


def probability_matrix():
    hot_probability = {(1, 'hot'): 0.2, (2, 'hot'): 0.4, (3, 'hot'): 0.4}
    cold_probability = {(1, 'cold'): 0.5, (2, 'cold'): 0.4, (3, 'cold'): 0.1}
    transition_probability = {('hot', 'hot'): 0.7, ('hot', 'cold'): 0.3, ('cold', 'cold'): 0.6, ('cold', 'hot'): 0.4}
    initial_hot = 0.8
    initial_cold = 0.2

    return hot_probability, cold_probability, transition_probability, initial_hot, initial_cold


def viterbi(sequence, hot_probability, cold_probability, transition_probability, initial_hot, initial_cold):
    hot_weather = []
    cold_weather = []
    hot_prob_list = []
    cold_prob_list = []
    states = [int(t) for t in str(sequence)]

    hot_initial = initial_hot * hot_probability[(states[0], 'hot')]
    cold_initial = initial_cold * cold_probability[(states[0], 'cold')]

    hot_weather.append((states[0], hot_initial, 'hot'))
    cold_weather.append((states[0], cold_initial, 'cold'))

    hot_prob_list.append(hot_initial)
    cold_prob_list.append(cold_initial)

    for i in range(1, len(states)):

        hot_to_hot = hot_prob_list[i - 1] * transition_probability[('hot', 'hot')] * hot_probability[(states[i], 'hot')]
        cold_to_cold = cold_prob_list[i - 1] * transition_probability[('cold', 'cold')] * cold_probability[
            (states[i], 'cold')]
        hot_to_cold = hot_prob_list[i - 1] * transition_probability[('hot', 'cold')] * cold_probability[
            (states[i], 'cold')]
        cold_to_hot = cold_prob_list[i - 1] * transition_probability[('cold', 'hot')] * hot_probability[
            (states[i], 'hot')]

        temp_hot = max(hot_to_hot, cold_to_hot)
        temp_cold = max(hot_to_cold, cold_to_cold)

        if temp_hot == hot_to_hot:
            hot_weather.append((states[i], hot_to_hot, 'hot'))
        else:
            hot_weather.append((states[i], cold_to_hot, 'cold'))

        if temp_cold == hot_to_cold:
            cold_weather.append((states[i], hot_to_cold, 'hot'))
        else:
            cold_weather.append((states[i], cold_to_cold, 'cold'))

        hot_prob_list.append(temp_hot)
        cold_prob_list.append(temp_cold)

    return hot_weather, cold_weather


def decoding(sequence, hot_weather, cold_weather):
    decode = []

    states = [int(t) for t in str(sequence)]
    no_of_states = len(states)

    if hot_weather[no_of_states - 1][1] > cold_weather[no_of_states - 1][1]:
        decode.append('hot')
        veterbi_probability = hot_weather[no_of_states - 1][1]

    else:
        decode.append('cold')
        veterbi_probability = cold_weather[no_of_states - 1][1]

    while no_of_states - 1 > 0:
        if hot_weather[no_of_states - 1][1] > cold_weather[no_of_states - 1][1]:
            decode.append(hot_weather[no_of_states - 1][2])

        else:
            decode.append(cold_weather[no_of_states - 1][2])

        no_of_states -= 1

    decode = decode[::-1]

    return decode, veterbi_probability


if __name__ == '__main__':
    hot_probability, cold_probability, transition_probability, initial_hot, initial_cold = probability_matrix()
    sequence = sys.argv[1]
    # sequence = 3333
    hot_weather, cold_weather = viterbi(sequence, hot_probability, cold_probability, transition_probability, initial_hot,
                                        initial_cold)
    weatherSequence, finalProb = decoding(sequence, hot_weather, cold_weather)

    print('Weather Sequence: ', weatherSequence)
    print('Probability: ', finalProb)
