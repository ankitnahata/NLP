HOW TO RUN:-

* Run the file veterbi.py
* On the command line interface type the file name with the python extension, 
  followed by one argument which contains the input sequence
  Eg: python veterbi.py 12132

OUTPUT:-

* The command line will display the following :
	* Weather Sequence
	* Probability of Sequence
**Minimum Python version required: 3.5